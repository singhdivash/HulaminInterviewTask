create or replace PROCEDURE insProd(
									
									p_sProdName		  	PRODUCTS.PRODUCTNAME%TYPE,
									p_nSupplierID	  	PRODUCTS.SUPPLIERID%TYPE,
									p_nCatID		  	PRODUCTS.CATEGORYID%TYPE,
									p_nQuantityPerUnit			  	PRODUCTS.QUANTITYPERUNIT%TYPE,
									p_nUnitPrice			  	PRODUCTS.UNITPRICE%TYPE,
									p_nUnitsInStock		  		PRODUCTS.UNITSINSTOCK%TYPE,
									p_nUnitsOnOrder		 	PRODUCTS.UNITSONORDER%TYPE,
									p_nReorderLevel		  	 	PRODUCTS.REORDERLEVEL%TYPE,
									p_sDiscontinued         	 	PRODUCTS.DISCONTINUED%TYPE
									) AS

BEGIN
DECLARE

   APPLICATION_USR_ERROR      EXCEPTION;

/**************************************************************************/
/* Variables                                                              */
/**************************************************************************/
   v_sTempString              VARCHAR2(500)  := NULL;

BEGIN
	

	/*****************************************************************/
	/* Insert statement to insert information into PRODUCTS   */
	/*****************************************************************/
	v_sTempString:= 'Err UPD PRODUCTS, COMPANY NAME :'||p_sProdName;

	INSERT INTO PRODUCTS 
		(PRODUCTNAME, 	
        SUPPLIERID, 		
		CATEGORYID,  		
		QUANTITYPERUNIT, 	
		UNITPRICE,  		
		UNITSINSTOCK, 		
		UNITSONORDER,  		
		REORDERLEVEL,  		
		DISCONTINUED)  	
		VALUES
		(
			p_sProdName,
			p_nSupplierID,
			p_nCatID,
			p_nQuantityPerUnit,
			p_nUnitPrice,
			p_nUnitsInStock,
			p_nUnitsOnOrder,
			p_nReorderLevel,
			p_sDiscontinued
		)


	;


/**************************************************************************/
/* Commit Changes                                                         */
/**************************************************************************/

    COMMIT;

/************************************/
/* Error Handling                   */
/************************************/
   EXCEPTION
      WHEN APPLICATION_USR_ERROR THEN
         ROLLBACK;
        

      WHEN OTHERS  THEN
         ROLLBACK;
        
END;
END insProd;