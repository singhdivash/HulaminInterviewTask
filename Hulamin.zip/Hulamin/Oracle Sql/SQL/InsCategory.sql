create or replace  PROCEDURE InsCategory(
									p_sCatName					  categories.categoryname%TYPE,
									p_sCatDesc                 categories.description%TYPE,
									p_sCatPic                     categories.picture%TYPE
							
                                ) AS

BEGIN
DECLARE

   APPLICATION_USR_ERROR      EXCEPTION;

/**************************************************************************/
/* Variables                                                              */
/**************************************************************************/
   v_sTempString              VARCHAR2(500)  := NULL;

BEGIN
	

	/*****************************************************************/
	/* Insert statement to insert information into CATEGORIES   */
	/*****************************************************************/
	v_sTempString:= 'Err Ins into CATEGORIES, NAME :'||p_sCatName||', DESCRIPTION: '||p_sCatDesc||'.';

	INSERT INTO CATEGORIES( CATEGORYNAME,
                          DESCRIPTION,
						  PICTURE
						 )
	VALUES (p_sCatName,
	        p_sCatDesc,
			p_sCatPic)
	;


/**************************************************************************/
/* Commit Changes                                                         */
/**************************************************************************/

    COMMIT;

/************************************/
/* Error Handling                   */
/************************************/
   EXCEPTION
      WHEN APPLICATION_USR_ERROR THEN
         ROLLBACK;
        

      WHEN OTHERS  THEN
         ROLLBACK;
         
END;
END InsCategory;