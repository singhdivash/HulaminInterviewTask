create or replace  PROCEDURE UpdProd(
									p_nProdID				PRODUCTS.PRODUCTID%TYPE,
									p_sProdName		  	PRODUCTS.PRODUCTNAME%TYPE,
									p_nSupplierID	  	PRODUCTS.SUPPLIERID%TYPE,
									p_nCatID		  	PRODUCTS.CATEGORYID%TYPE,
									p_nQuantityPerUnit			  	PRODUCTS.QUANTITYPERUNIT%TYPE,
									p_nUnitPrice			  	PRODUCTS.UNITPRICE%TYPE,
									p_nUnitsInStock		  		PRODUCTS.UNITSINSTOCK%TYPE,
									p_nUnitsOnOrder		 	PRODUCTS.UNITSONORDER%TYPE,
									p_nReorderLevel		  	 	PRODUCTS.REORDERLEVEL%TYPE,
									p_sDiscontinued         	 	PRODUCTS.DISCONTINUED%TYPE
									) AS

BEGIN
DECLARE

   APPLICATION_USR_ERROR      EXCEPTION;

/**************************************************************************/
/* Variables                                                              */
/**************************************************************************/
   v_sTempString              VARCHAR2(500)  := NULL;

BEGIN


	/*****************************************************************/
	/* update statement to update information on PRODUCTS   */
	/*****************************************************************/
	v_sTempString:= 'Err UPD PRODUCTS, PRODUCT NAME :'||p_sProdName;

	UPDATE PRODUCTS 
	SET	PRODUCTNAME = p_sProdName,
        SUPPLIERID = p_nSupplierID,
		CATEGORYID = p_nCatID,
		QUANTITYPERUNIT = p_nQuantityPerUnit,
		UNITPRICE = p_nUnitPrice,
		UNITSINSTOCK = p_nUnitsInStock,
		UNITSONORDER = p_nUnitsOnOrder,
		REORDERLEVEL = p_nReorderLevel,
		DISCONTINUED = p_sDiscontinued

	WHERE PRODUCTID = p_nProdID
	;


/**************************************************************************/
/* Commit Changes                                                         */
/**************************************************************************/

    COMMIT;

/************************************/
/* Error Handling                   */
/************************************/
   EXCEPTION
      WHEN APPLICATION_USR_ERROR THEN
         ROLLBACK;
        

      WHEN OTHERS  THEN
         ROLLBACK;
       
END;
END UpdProd;