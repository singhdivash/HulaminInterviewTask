create or replace PROCEDURE UpdSupplier(
									p_nSuppId				SUPPLIERS.SUPPLIERID%TYPE,
									p_sCompanyName		  	SUPPLIERS.COMPANYNAME%TYPE,
									p_sContactName		  	SUPPLIERS.CONTACTNAME%TYPE,
									p_sContactTitle		  	SUPPLIERS.CONTACTTITLE%TYPE,
									p_sAddress			  	SUPPLIERS.ADDRESS%TYPE,
									p_sCity				  	SUPPLIERS.CITY%TYPE,
									p_sRegion		  		SUPPLIERS.REGION%TYPE,
									p_sCountry		  	 	SUPPLIERS.COUNTRY%TYPE,
									p_sPhone         	 	SUPPLIERS.PHONE%TYPE,
									p_sFax         		 	SUPPLIERS.FAX%TYPE,
									p_sHomePage		 	SUPPLIERS.HOMEPAGE%TYPe
									) AS

BEGIN
DECLARE

   APPLICATION_USR_ERROR      EXCEPTION;

/**************************************************************************/
/* Variables                                                              */
/**************************************************************************/
   v_sTempString              VARCHAR2(500)  := NULL;

BEGIN



	/*****************************************************************/
	/* update statement to update information on SUPPLIERS   */
	/*****************************************************************/
	v_sTempString:= 'Err UPD SUPPLIERS, COMPANY NAME :'||p_sCompanyName||', Cell_No: '||p_sPhone||' FAX '||p_sFax||'.';

	UPDATE SUPPLIERS 
	SET	COMPANYNAME = p_sCompanyName,
        CONTACTNAME = p_sContactName,
		CONTACTTITLE = p_sContactTitle,
		ADDRESS = p_sAddress,
		CITY = p_sCity,
		REGION = p_sRegion,

		COUNTRY = p_sCountry,
		PHONE = p_sPhone,
		FAX = p_sFax,
		HOMEPAGE = p_sHomePage
	WHERE SUPPLIERID = p_nSuppId
	;


/**************************************************************************/
/* Commit Changes                                                         */
/**************************************************************************/

    COMMIT;

/************************************/
/* Error Handling                   */
/************************************/
   EXCEPTION
      WHEN APPLICATION_USR_ERROR THEN
         ROLLBACK;
         

      WHEN OTHERS  THEN
         ROLLBACK;
        
END;
END UpdSupplier;