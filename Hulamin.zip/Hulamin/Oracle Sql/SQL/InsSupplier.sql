create or replace  PROCEDURE InsSupplier(
									p_sCompanyName		  	SUPPLIERS.COMPANYNAME%TYPE,
									p_sContactName		  	SUPPLIERS.CONTACTNAME%TYPE,
									p_sContactTitle		  	SUPPLIERS.CONTACTTITLE%TYPE,
									p_sAddress			  	SUPPLIERS.ADDRESS%TYPE,
									p_sCity				  	SUPPLIERS.CITY%TYPE,
									p_sRegion		  		SUPPLIERS.REGION%TYPE,
									p_sCountry		  	 	SUPPLIERS.COUNTRY%TYPE,
									p_sPhone         	 	SUPPLIERS.PHONE%TYPE,
									p_sFax         		 	SUPPLIERS.FAX%TYPE,
									p_sHomePage				SUPPLIERS.HOMEPAGE%TYPE
									) AS

BEGIN
DECLARE

   APPLICATION_USR_ERROR      EXCEPTION;

/**************************************************************************/
/* Variables                                                              */
/**************************************************************************/
   v_sTempString              VARCHAR2(500)  := NULL;

BEGIN



	/*****************************************************************/
	/* Insert statement to insert information into SUPPLIERS   */
	/*****************************************************************/
	v_sTempString:= 'Err Ins into SUPPLIERS, EmpNo :'||p_sCompanyName||', Cell_No: '||p_sPhone||' FAX '||p_sFax||'.';

	INSERT INTO SUPPLIERS( COMPANYNAME,
                          CONTACTNAME,
						  CONTACTTITLE,
						  ADDRESS,
						  CITY,
						  REGION,
						  COUNTRY,
						  PHONE,
						  FAX,
                          HOMEPAGE)
	VALUES (p_sCompanyName,
	        p_sContactName,
			p_sContactTitle,
			p_sAddress,
			p_sCity,
			p_sRegion,
			p_sCountry,
			p_sPhone,
			p_sFax,
            p_sHomePage)
	;


/**************************************************************************/
/* Commit Changes                                                         */
/**************************************************************************/

    COMMIT;

/************************************/
/* Error Handling                   */
/************************************/
   EXCEPTION
      WHEN APPLICATION_USR_ERROR THEN
         ROLLBACK;


      WHEN OTHERS  THEN
         ROLLBACK;

END;
END InsSupplier;