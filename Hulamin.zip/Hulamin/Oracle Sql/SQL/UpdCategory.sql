create or replace  PROCEDURE UpdCategory(
                                    p_nCatId					  categories.categoryid%TYPE,
									p_sCatName					  categories.categoryname%TYPE,
									p_sCatDesc                 categories.description%TYPE,
									p_sCatPic                     categories.picture%TYPE
									) AS

BEGIN
DECLARE

   APPLICATION_USR_ERROR      EXCEPTION;

/**************************************************************************/
/* Variables                                                              */
/**************************************************************************/
   v_sTempString              VARCHAR2(500)  := NULL;

BEGIN


	/*****************************************************************/
	/* update statement to update information on CATEGORIES   */
	/*****************************************************************/
	v_sTempString:= 'Err upd CATEGORIES, NAME :'||p_sCatName||', DESCRIPTION: '||p_sCatDesc||'.';

	UPDATE CATEGORIES
        SET categoryname = p_sCatName,
            description = p_sCatDesc,
            picture = p_sCatPic
        where categoryid = p_nCatId;



/**************************************************************************/
/* Commit Changes                                                         */
/**************************************************************************/

    COMMIT;

/************************************/
/* Error Handling                   */
/************************************/
   EXCEPTION
      WHEN APPLICATION_USR_ERROR THEN
         ROLLBACK;
        

      WHEN OTHERS  THEN
         ROLLBACK;
       
END;
END UpdCategory;