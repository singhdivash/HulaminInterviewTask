﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        public void Products_Load(object sender, EventArgs e)
        {
           
            DataSet ds = new DataSet();
            ProductsModel productsModel = new ProductsModel();
            ds = productsModel.PopGrid();
            if (ds.Tables.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            DataSet ds = new DataSet();
            ProductsModel productsModel = new ProductsModel();
            ds = productsModel.PopGrid(txtSearch.Text);
            if (ds.Tables.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductsModel productsModel = new ProductsModel();

            productsModel.ProductId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            productsModel.ProductName = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            productsModel.SupplierId = 0;
            productsModel.CategoryId = 0;
            productsModel.QuantityPerUnit = Convert.ToInt32(dataGridView1.CurrentRow.Cells[4].Value);
            productsModel.UnitPrice = Convert.ToDouble(dataGridView1.CurrentRow.Cells[5].Value);
            productsModel.UnitsInStock = Convert.ToInt32(dataGridView1.CurrentRow.Cells[6].Value);
            productsModel.UnitsOnOrder = Convert.ToInt32(dataGridView1.CurrentRow.Cells[7].Value);
            productsModel.ReorderLevel = Convert.ToInt32(dataGridView1.CurrentRow.Cells[8].Value);
            productsModel.Discont = dataGridView1.CurrentRow.Cells[9].Value.ToString();

            string strSupplier = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            string strCategory = dataGridView1.CurrentRow.Cells[3].Value.ToString();


            this.Close();
            Form ProdUpdForm = new ProductsUpdate(productsModel, strSupplier, strCategory);
            ProdUpdForm.Show();

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            this.Close();
        }
    }
}
