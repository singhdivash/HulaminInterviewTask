﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class CategoryUpdate : Form
    {
       
        public CategoryUpdate(CategoriesModel categoriesModel)
        {
            
            InitializeComponent();
            txtCatId.Text = categoriesModel.CategoryId.ToString();
            txtCatName.Text = categoriesModel.CategoryName;
            txtCatDesc.Text = categoriesModel.CategoryDescription;
            txtCatPic.Text = categoriesModel.CategoryPicture;
        }

        public void CategoryUpdate_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(CategoryId);
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            CategoriesModel categoriesModel = new CategoriesModel();
            categoriesModel.CategoryId = Convert.ToInt32(txtCatId.Text);
            categoriesModel.CategoryName = txtCatName.Text.ToUpper();
            categoriesModel.CategoryDescription = txtCatDesc.Text;
            categoriesModel.CategoryPicture = txtCatPic.Text;

            categoriesModel.UpdateCategory(categoriesModel);
            Categories categories = new Categories();
            this.Close();
            categories.FormClosing += new FormClosingEventHandler(ChildFormClosing);
            categories.Show();
        }

        private void ChildFormClosing(object sender, FormClosingEventArgs e)
        {
            Categories categories = new Categories();
            categories.Form1_Load(sender, e);
        }
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            CategoriesModel categoriesModel = new CategoriesModel();
            categoriesModel.DeleteCategory(Convert.ToInt32(txtCatId.Text));
            this.Close();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
