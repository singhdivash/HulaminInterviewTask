﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class ProductsCreate : Form
    {
        public ProductsCreate()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ProductsModel productsModel = new ProductsModel();
            productsModel.ProductId = 0;
            productsModel.ProductName = txtProdName.Text;
            productsModel.CategoryId = Convert.ToInt32(cmbCategory.SelectedValue);
            productsModel.SupplierId = Convert.ToInt32(cmbSupplier.SelectedValue);
            productsModel.QuantityPerUnit = Convert.ToInt32(numQuantity.Value);
            productsModel.UnitPrice = Convert.ToDouble(txtUnitPrice.Text);
            productsModel.UnitsInStock = Convert.ToInt32(numUnitsInStock.Value);
            productsModel.ReorderLevel = Convert.ToInt32(numReorderLevel.Value);
            if (cbDiscontinued.Checked)
            {
                productsModel.Discont = "True";
            }
            else
            {
                productsModel.Discont = "False";
            }


            productsModel.CreateProduct(productsModel);
            this.Close();

        }

        private void ProductsCreate_Load(object sender, EventArgs e)
        {
            {

                try
                {
                    string conString = Properties.Settings.Default.ConnectionString;
                    using (OracleConnection con = new OracleConnection(conString))
                    {
                        OracleCommand cmd = new OracleCommand("SELECT CATEGORYNAME, CATEGORYID  FROM CATEGORIES", con);
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {

                            cmbCategory.DataSource = dt;
                            cmbCategory.DisplayMember = "CATEGORYNAME";
                            cmbCategory.ValueMember = "CATEGORYID";
                        }
                    }
                }
                catch (Exception EX)
                {

                    MessageBox.Show(EX.ToString());

                }


                try
                {
                    string conString = Properties.Settings.Default.ConnectionString;
                    using (OracleConnection con = new OracleConnection(conString))
                    {
                        OracleCommand cmd = new OracleCommand("SELECT SUPPLIERID, COMPANYNAME  FROM SUPPLIERS", con);
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            cmbSupplier.DataSource = dt;
                            cmbSupplier.DisplayMember = "COMPANYNAME";
                            cmbSupplier.ValueMember = "SUPPLIERID";
                        }
                    }
                }
                catch (Exception EX)
                {

                    MessageBox.Show(EX.ToString());

                }

            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
