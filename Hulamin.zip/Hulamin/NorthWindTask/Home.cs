﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorthWindTask
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Form CatCreateForm = new CategoriesCreate();
            CatCreateForm.ShowDialog();
            
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Form CatViewForm = new Categories();
            CatViewForm.ShowDialog();
            
        }

        private void createToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            Form SupCreateForm = new SuppliersCreate();
            SupCreateForm.ShowDialog();
            
        }

        private void viewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            Form SuppliersViewForm = new Suppliers();
            SuppliersViewForm.ShowDialog();
            
        }

        private void createToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            
            Form ProdCreateForm = new ProductsCreate();
            ProdCreateForm.ShowDialog();
            
        }
        private void viewToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            
            Form ProdViewForm = new Products();
            ProdViewForm.ShowDialog();
            
        }

       
    }
}
