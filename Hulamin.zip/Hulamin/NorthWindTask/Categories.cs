﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using NorthWindTask.Models;
//using Oracle.DataAccess.Client;

namespace NorthWindTask
{
    public partial class Categories : Form
    {
        public Categories()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            //Call the populate procedure from CategoriesModel, and populdate the data grid on form load
            try
            {
                CategoriesModel categoriesModel = new CategoriesModel();
                DataSet ds = new DataSet();
                ds = categoriesModel.PopGrid();
                if (ds.Tables.Count > 0)
                {
                    dataGridView1.DataSource = ds.Tables[0].DefaultView;
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }

        }
        //Call the populate procedure from CategoriesModel, and populate the data grid based on the search string
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(txtSearch.Text);
            try
            {
                CategoriesModel categoriesModel = new CategoriesModel();
                DataSet ds = new DataSet();
                ProductsModel productsModel = new ProductsModel();
                ds = categoriesModel.PopGrid(txtSearch.Text);
                if (ds.Tables.Count > 0)
                {
                    dataGridView1.DataSource = ds.Tables[0].DefaultView;
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
            

        }

        //Initialize an object of CategoriesModel type and pass it to the update form
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CategoriesModel categoriesModel = new CategoriesModel();
            categoriesModel.CategoryId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            categoriesModel.CategoryName = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            categoriesModel.CategoryDescription = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            categoriesModel.CategoryPicture = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            this.Close();
            Form CatUpdForm = new CategoryUpdate(categoriesModel);
            CatUpdForm.Show();
           



        }


        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
