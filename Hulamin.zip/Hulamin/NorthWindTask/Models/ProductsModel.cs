﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace NorthWindTask.Models
{
    public class ProductsModel
    {
        public int ProductId;
        public string ProductName;
        public int SupplierId;
        public int CategoryId;
        public int QuantityPerUnit;
        public double UnitPrice;
        public int UnitsInStock;
        public int UnitsOnOrder;
        public int ReorderLevel;
        public string Discont;

        //Accept a object of ProductsModel type, set up Oracle parameters and call the Oracle proc to update a product
        public void UpdateProduct(ProductsModel productsModel)
        {

            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection objConn = new OracleConnection(conString))
            {
                OracleCommand objCmd = new OracleCommand();
                objCmd.Connection = objConn;
                objCmd.CommandText = "updProd";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add("p_nProdID", OracleType.VarChar).Value = Convert.ToInt32(productsModel.ProductId);
                objCmd.Parameters.Add("p_sProdName", OracleType.VarChar).Value = productsModel.ProductName.ToUpper();
                objCmd.Parameters.Add("p_nSupplierID", OracleType.VarChar).Value = Convert.ToInt32(productsModel.SupplierId);
                objCmd.Parameters.Add("p_nCatID", OracleType.VarChar).Value = Convert.ToInt32(productsModel.CategoryId);
                objCmd.Parameters.Add("p_nQuantityPerUnit", OracleType.VarChar).Value = Convert.ToInt32(productsModel.QuantityPerUnit);
                objCmd.Parameters.Add("p_nUnitPrice", OracleType.Number).Value = Convert.ToDecimal(productsModel.UnitPrice);
                objCmd.Parameters.Add("p_nUnitsInStock", OracleType.VarChar).Value = Convert.ToInt32(productsModel.UnitsInStock);
                objCmd.Parameters.Add("p_nUnitsOnOrder", OracleType.VarChar).Value = Convert.ToInt32(productsModel.UnitsOnOrder);
                objCmd.Parameters.Add("p_nReorderLevel", OracleType.VarChar).Value = Convert.ToInt32(productsModel.ReorderLevel);
                objCmd.Parameters.Add("p_sDiscontinued", OracleType.VarChar).Value = productsModel.Discont;

                try
                {
                    objConn.Open();
                    objCmd.ExecuteNonQuery();
                    MessageBox.Show("Product Updated!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                objConn.Close();
            }

        }

        //Accept a object of ProductsModel type, set up Oracle parameters and call the Oracle proc to insert a product
        public void CreateProduct(ProductsModel productsModel)
        {

            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection objConn = new OracleConnection(conString))
            {
                OracleCommand objCmd = new OracleCommand();
                objCmd.Connection = objConn;
                objCmd.CommandText = "insProd";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add("p_sProdName", OracleType.VarChar).Value = productsModel.ProductName.ToUpper();
                objCmd.Parameters.Add("p_nSupplierID", OracleType.VarChar).Value = Convert.ToInt32(productsModel.SupplierId);
                objCmd.Parameters.Add("p_nCatID", OracleType.VarChar).Value = Convert.ToInt32(productsModel.CategoryId);
                objCmd.Parameters.Add("p_nQuantityPerUnit", OracleType.VarChar).Value = Convert.ToInt32(productsModel.QuantityPerUnit);
                objCmd.Parameters.Add("p_nUnitPrice", OracleType.Number).Value = Convert.ToDecimal(productsModel.UnitPrice);
                objCmd.Parameters.Add("p_nUnitsInStock", OracleType.VarChar).Value = Convert.ToInt32(productsModel.UnitsInStock);
                objCmd.Parameters.Add("p_nUnitsOnOrder", OracleType.VarChar).Value = Convert.ToInt32(productsModel.UnitsOnOrder);
                objCmd.Parameters.Add("p_nReorderLevel", OracleType.VarChar).Value = Convert.ToInt32(productsModel.ReorderLevel);
                objCmd.Parameters.Add("p_sDiscontinued", OracleType.VarChar).Value = productsModel.Discont;

                try
                {
                    objConn.Open();
                    objCmd.ExecuteNonQuery();
                    MessageBox.Show("Product Created!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                objConn.Close();
            }

        }


        //Delete a product based on the ID of the record we wish to delete
        public void DeleteProduct(int ProdId)
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("DELETE FROM PRODUCTS WHERE PRODUCTID = " + ProdId, con);
                    cmd.Connection = con;

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data Deleted!");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.ToString());
                    }

                    MessageBox.Show("Record deleted");
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
            }
        }

        //Populate the initial data in the grid
        public DataSet PopGrid()
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT A.PRODUCTID, A.PRODUCTNAME,B.COMPANYNAME,C.CATEGORYNAME,A.QUANTITYPERUNIT,A.UNITPRICE,A.UNITSINSTOCK,A.UNITSONORDER,A.REORDERLEVEL,A.DISCONTINUED FROM PRODUCTS A, SUPPLIERS B, CATEGORIES C WHERE a.supplierid = B.SUPPLIERID AND a.categoryid = c.categoryid", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    oda.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        con.Close();
                        return ds;
                        
                    }
                    else
                    {
                        con.Close();
                        return null;
                    }
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
                return null;
            }
        }

        //Populate the data in the grid based on a search string being passed in
        public DataSet PopGrid(string searchString)
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT A.PRODUCTID, A.PRODUCTNAME,B.COMPANYNAME,C.CATEGORYNAME,A.QUANTITYPERUNIT,A.UNITPRICE,A.UNITSINSTOCK,A.UNITSONORDER,A.REORDERLEVEL,A.DISCONTINUED FROM PRODUCTS A, SUPPLIERS B, CATEGORIES C WHERE a.supplierid = B.SUPPLIERID AND a.categoryid = c.categoryid AND PRODUCTNAME LIKE '%" + searchString.ToUpper() + "%'", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    oda.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        con.Close();
                        return ds;

                    }
                    else
                    {
                        con.Close();
                        return null;
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
                return null;
            }
        }


        
    }
}
