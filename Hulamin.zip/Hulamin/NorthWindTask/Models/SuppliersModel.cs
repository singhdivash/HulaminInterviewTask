﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data;
using System.Data.OracleClient;

namespace NorthWindTask.Models
{
    public  class SuppliersModel
    {
        public int  SupplierID;
        public string CompanyName;
        public string ContactName;
        public string ContactTitle;
        public string Address;
        public string City;
        public string Region;
        public string Country;
        public string Phone;
        public string Fax;
        public string HomePage;

        //Accept a argument of SuppliersModel type, and set up params to call the Oracle Insert procedure
        public void CreateSupplier(SuppliersModel suppliersModel)
        {
            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection objConn = new OracleConnection(conString))
            {
                OracleCommand objCmd = new OracleCommand();
                objCmd.Connection = objConn;
                objCmd.CommandText = "insSupplier";
                objCmd.CommandType = CommandType.StoredProcedure;
               // objCmd.Parameters.Add("p_nSuppId", OracleType.VarChar).Value = suppID;
                objCmd.Parameters.Add("p_sCompanyName", OracleType.VarChar).Value = suppliersModel.CompanyName.ToUpper();
                objCmd.Parameters.Add("p_sContactName", OracleType.VarChar).Value = suppliersModel.ContactName;
                objCmd.Parameters.Add("p_sContactTitle", OracleType.VarChar).Value = suppliersModel.ContactTitle;
                objCmd.Parameters.Add("p_sAddress", OracleType.VarChar).Value = suppliersModel.Address;
                objCmd.Parameters.Add("p_sCity", OracleType.VarChar).Value = suppliersModel.City;
                objCmd.Parameters.Add("p_sRegion", OracleType.VarChar).Value = suppliersModel.Region;
                objCmd.Parameters.Add("p_sCountry", OracleType.VarChar).Value = suppliersModel.Country;
                objCmd.Parameters.Add("p_sPhone", OracleType.VarChar).Value = suppliersModel.Phone;
                objCmd.Parameters.Add("p_sFax", OracleType.VarChar).Value = suppliersModel.Fax;
                objCmd.Parameters.Add("p_sHomePage", OracleType.VarChar).Value = suppliersModel.HomePage;
                try
                {
                    objConn.Open();
                    objCmd.ExecuteNonQuery();
                    MessageBox.Show("Supplier Created!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                objConn.Close();
            }
        }

        //Accept a argument of SuppliersModel type, and set up params to call the Oracle Update procedure
        public void UpdateSupplier(SuppliersModel suppliersModel)
        {
            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection objConn = new OracleConnection(conString))
            {
                OracleCommand objCmd = new OracleCommand();
                objCmd.Connection = objConn;
                objCmd.CommandText = "updSupplier";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add("p_nSuppId", OracleType.VarChar).Value = suppliersModel.SupplierID;
                objCmd.Parameters.Add("p_sCompanyName", OracleType.VarChar).Value = suppliersModel.CompanyName.ToUpper();
                objCmd.Parameters.Add("p_sContactName", OracleType.VarChar).Value = suppliersModel.ContactName;
                objCmd.Parameters.Add("p_sContactTitle", OracleType.VarChar).Value = suppliersModel.ContactTitle;
                objCmd.Parameters.Add("p_sAddress", OracleType.VarChar).Value = suppliersModel.Address;
                objCmd.Parameters.Add("p_sCity", OracleType.VarChar).Value = suppliersModel.City;
                objCmd.Parameters.Add("p_sRegion", OracleType.VarChar).Value = suppliersModel.Region;
                objCmd.Parameters.Add("p_sCountry", OracleType.VarChar).Value = suppliersModel.Country;
                objCmd.Parameters.Add("p_sPhone", OracleType.VarChar).Value = suppliersModel.Phone;
                objCmd.Parameters.Add("p_sFax", OracleType.VarChar).Value = suppliersModel.Fax;
                objCmd.Parameters.Add("p_sHomePage", OracleType.VarChar).Value = suppliersModel.HomePage;
                try
                {
                    objConn.Open();
                    objCmd.ExecuteNonQuery();
                    MessageBox.Show("Supplier Updated!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                objConn.Close();
            }
        }

        //Delete a desired record based on the ID of the supplier we wish to delete
        public void DeleteSupplier(int SuppId)
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("DELETE FROM SUPPLIERS WHERE SUPPLIERID = " + SuppId, con);
                    cmd.Connection = con;

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data Deleted!");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.ToString());
                    }


                }

            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
            }
        }
        //Populate the data based on a search string being passed in
        public DataSet PopGrid(string searchString)
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT * FROM SUPPLIERS WHERE COMPANYNAME LIKE '%" + searchString.ToUpper() + "%'", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    oda.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        con.Close();
                        return ds;
                    }
                    else
                    {
                        con.Close();
                        return null;
                    }
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
                return null;
            }
        }

        //Populate the data from the initial load of the Suppliers Form
        public DataSet PopGrid()
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT * FROM SUPPLIERS", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    oda.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        con.Close();
                        return ds;
                    }
                    else
                    {
                        con.Close();
                        return null;
                    }
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
                return null;
            }
        }
    }

    
}
