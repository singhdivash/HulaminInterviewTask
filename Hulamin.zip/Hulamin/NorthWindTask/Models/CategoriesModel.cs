﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace NorthWindTask.Models
{
    public class CategoriesModel
    {
        public int CategoryId;
        public string CategoryName;
        public string CategoryDescription;
        public string CategoryPicture;

        //Accept a parameter of the categories obeject, set up the Oracle parameters and call the update function for a category
        public void UpdateCategory(CategoriesModel categoriesModel)
        {

            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection objConn = new OracleConnection(conString))
            {
                OracleCommand objCmd = new OracleCommand();
                objCmd.Connection = objConn;
                objCmd.CommandText = "updCategory";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add("p_nCatID", OracleType.VarChar).Value = Convert.ToInt32(categoriesModel.CategoryId);
                objCmd.Parameters.Add("p_sCatName", OracleType.VarChar).Value = categoriesModel.CategoryName.ToUpper();
                objCmd.Parameters.Add("p_sCatDesc", OracleType.VarChar).Value = categoriesModel.CategoryDescription.ToUpper();
                objCmd.Parameters.Add("p_sCatPic", OracleType.VarChar).Value = categoriesModel.CategoryPicture.ToUpper();

                try
                {
                    objConn.Open();
                    objCmd.ExecuteNonQuery();
                    MessageBox.Show("Category Updated!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                objConn.Close();
            }

        }

        //Accept a parameter of the categories obeject, set up the Oracle parameters and call the create function for a category
        public void CreateCategory(CategoriesModel categoriesModel)
        {

            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection objConn = new OracleConnection(conString))
            {
                OracleCommand objCmd = new OracleCommand();
                objCmd.Connection = objConn;
                objCmd.CommandText = "insCategory";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add("p_sCatName", OracleType.VarChar).Value = categoriesModel.CategoryName.ToUpper();
                objCmd.Parameters.Add("p_sCatDesc", OracleType.VarChar).Value = categoriesModel.CategoryDescription;
                objCmd.Parameters.Add("p_sCatPic", OracleType.VarChar).Value = categoriesModel.CategoryPicture;

                try
                {
                    objConn.Open();
                    objCmd.ExecuteNonQuery();
                    MessageBox.Show("Category Updated!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                objConn.Close();
            }

        }

        //Delete a category using the Id of the record we wish to delete
        public void DeleteCategory(int CatId)
        {

            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection con = new OracleConnection(conString))
            {
                OracleCommand cmd = new OracleCommand("DELETE FROM CATEGORIES WHERE CATEGORYID = " + CatId, con);
                cmd.Connection = con;

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted!");
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.ToString());
                }

                con.Close();

            }




        }

        //Populate the data when the categories form initially loads up
        public DataSet PopGrid()
        {

            string conString = Properties.Settings.Default.ConnectionString;
            using (OracleConnection con = new OracleConnection(conString))
            {
                OracleCommand cmd = new OracleCommand("SELECT * FROM CATEGORIES", con);
                OracleDataAdapter oda = new OracleDataAdapter(cmd);
                DataSet ds = new DataSet();
                oda.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    con.Close();
                    return ds;


                }
                else
                {
                    con.Close();
                    return null;
                }


            }


        }

        //Populate the data when the categories form search parameter is passed
        public DataSet PopGrid(string searchString)
        {
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT * FROM CATEGORIES WHERE CATEGORYNAME LIKE '%" + searchString.ToUpper() + "%'", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    oda.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        con.Close();
                        return ds;
                        

                    }
                    else
                    {
                        con.Close();
                        return null;
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
                return null;
            }
        }
    }
}
