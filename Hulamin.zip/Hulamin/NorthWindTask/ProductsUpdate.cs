﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NorthWindTask.Models;
using System.Data.OracleClient;

namespace NorthWindTask
{
    public partial class ProductsUpdate : Form
    {
       
        public ProductsUpdate(ProductsModel productsModel, string strSupplier, string strCategory)
        {
            //Load up the values for the record which we which to update
            InitializeComponent();
            txtProdID.Text = productsModel.ProductId.ToString();
            txtProdName.Text = productsModel.ProductName.ToString();
            txtUnitPrice.Text = productsModel.UnitPrice.ToString();
            cmbCategory.Text = strCategory;
            cmbSupplier.Text = strSupplier;
            numQuantity.Value = productsModel.QuantityPerUnit;
            numReorderLevel.Value = productsModel.ReorderLevel;
            numUnitsInStock.Value = productsModel.UnitsInStock;
            numUnitsOnoRder.Value = productsModel.UnitsOnOrder;
            if(productsModel.Discont == "True")
            {
                cbDiscontinued.Checked = true;
            }
            else
            {
                cbDiscontinued.Checked = false;
            }           

    }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void ProductsUpdate_Load(object sender, EventArgs e)
        {
            //Populuate the categories Combo box for the product update with the possible categories
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT CATEGORYNAME, CATEGORYID  FROM CATEGORIES", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    oda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        cmbCategory.DataSource = dt;
                        cmbCategory.DisplayMember = "CATEGORYNAME";
                        cmbCategory.ValueMember = "CATEGORYID";
                    }
                }
            }
            catch (Exception EX)
            {

                MessageBox.Show(EX.ToString());
                
            }

            //Populuate the Suppliers Combo box for the product update with the possible  suppliers
            try
            {
                string conString = Properties.Settings.Default.ConnectionString;
                using (OracleConnection con = new OracleConnection(conString))
                {
                    OracleCommand cmd = new OracleCommand("SELECT SUPPLIERID, COMPANYNAME  FROM SUPPLIERS", con);
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    oda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        cmbSupplier.DataSource = dt;
                        cmbSupplier.DisplayMember = "COMPANYNAME";
                        cmbSupplier.ValueMember = "SUPPLIERID";
                    }
                }
            }
            catch (Exception EX)
            {

                MessageBox.Show(EX.ToString());

            }

        }

        
        private void btnSave_Click(object sender, EventArgs e)
        {
            ProductsModel productsModel = new ProductsModel();
            productsModel.ProductId = Convert.ToInt32(txtProdID.Text);
            productsModel.ProductName = txtProdName.Text;
            productsModel.CategoryId = Convert.ToInt32(cmbCategory.SelectedValue);
            productsModel.SupplierId = Convert.ToInt32(cmbSupplier.SelectedValue);
            productsModel.QuantityPerUnit = Convert.ToInt32(numQuantity.Value);
            productsModel.UnitPrice = Convert.ToDouble(txtUnitPrice.Text);
            productsModel.UnitsInStock = Convert.ToInt32(numUnitsInStock.Value);
            productsModel.ReorderLevel = Convert.ToInt32(numReorderLevel.Value);
            if(cbDiscontinued.Checked)
            {
                productsModel.Discont = "True";
            }
            else
            {
                productsModel.Discont = "False";
            }


            productsModel.UpdateProduct(productsModel);
            Products products = new Products();
            this.Close();
            products.FormClosing += new FormClosingEventHandler(ChildFormClosing);
            products.Show();
        }
        
        private void ChildFormClosing(object sender, FormClosingEventArgs e)
        {
            Products products = new Products();
            products.Products_Load(sender, e);
        }
    

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ProductsModel productsModel = new ProductsModel();
            productsModel.DeleteProduct(Convert.ToInt32(txtProdID.Text));
            this.Close();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
