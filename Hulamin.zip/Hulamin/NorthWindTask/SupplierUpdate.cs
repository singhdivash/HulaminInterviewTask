﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class SupplierUpdate : Form
    {
        public SupplierUpdate(SuppliersModel suppliersModel)
        {
            InitializeComponent();
            txtSuppID.Text = suppliersModel.SupplierID.ToString();
            txtCity.Text = suppliersModel.City.ToString();
            txtAddress.Text = suppliersModel.Address.ToString();
            txtCompanyName.Text = suppliersModel.CompanyName.ToString();
            txtContactName.Text = suppliersModel.ContactName.ToString();
            txtContactTitle.Text = suppliersModel.ContactTitle.ToString();
            txtCountry.Text = suppliersModel.Country.ToString();
            txtFax.Text = suppliersModel.Fax.ToString();   
            txtHomePage .Text = suppliersModel.HomePage.ToString();
            txtPhone.Text = suppliersModel.Phone.ToString();
            txtRegion.Text = suppliersModel.Region.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SuppliersModel suppliersModel = new SuppliersModel();
            suppliersModel.SupplierID = Convert.ToInt32(txtSuppID.Text);
            suppliersModel.CompanyName = txtCompanyName.Text;
            suppliersModel.ContactName = txtContactName.Text;
            suppliersModel.ContactTitle = txtContactTitle.Text;
            suppliersModel.Address = txtAddress.Text;
            suppliersModel.City = txtCity.Text;
            suppliersModel.Region = txtRegion.Text;
            suppliersModel.Country = txtCountry.Text;
            suppliersModel.Phone = txtPhone.Text;
            suppliersModel.Fax = txtFax.Text;
            suppliersModel.HomePage = txtHomePage.Text;

            suppliersModel.UpdateSupplier(suppliersModel);
            Suppliers suppliers = new Suppliers();
            this.Close();
            suppliers.FormClosing += new FormClosingEventHandler(ChildFormClosing);
            suppliers.Show();
        }

        private void ChildFormClosing(object sender, FormClosingEventArgs e)
        {
            Suppliers suppliers = new Suppliers();
            suppliers.Suppliers_Load(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SuppliersModel suppliersModel = new SuppliersModel();
            suppliersModel.DeleteSupplier(Convert.ToInt32(txtSuppID.Text));
        }

        

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
