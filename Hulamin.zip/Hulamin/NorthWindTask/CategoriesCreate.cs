﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class CategoriesCreate : Form
    {
        public CategoriesCreate()
        {
            InitializeComponent();
        }

        //Set up a CategoriesModel object and call the create function
        private void BtnSave_Click(object sender, EventArgs e)
        {
            CategoriesModel categoriesModel = new CategoriesModel();
            categoriesModel.CategoryId = 0;
            categoriesModel.CategoryName = txtCatName.Text.ToUpper();
            categoriesModel.CategoryDescription = txtCatDesc.Text;
            categoriesModel.CategoryPicture = txtCatPic.Text;

            categoriesModel.CreateCategory(categoriesModel);
            
        }

        
        //Cancel changes and revert to display screen
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
