﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class Suppliers : Form
    {
        public Suppliers()
        {
            InitializeComponent();
        }

        public void Suppliers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.SUPPLIERS' table. You can move, or remove it, as needed.
            //this.sUPPLIERSTableAdapter.Fill(this.dataSet1.SUPPLIERS);
            DataSet ds = new DataSet();
            SuppliersModel suppliersModel = new SuppliersModel();
            ds = suppliersModel.PopGrid();
            if (ds.Tables.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }

        }

        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SuppliersModel suppliersModel = new SuppliersModel();
            suppliersModel.SupplierID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            suppliersModel.CompanyName = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            suppliersModel.ContactName = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            suppliersModel.ContactTitle = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            suppliersModel.Address = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            suppliersModel.City = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            suppliersModel.Region = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            suppliersModel.Country = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            suppliersModel.Phone = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            suppliersModel.Fax = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            suppliersModel.HomePage = dataGridView1.CurrentRow.Cells[10].Value.ToString();
            //string strID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            //string strCatName = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            //string strCatDesc = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            //string strCatPic = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            //MessageBox.Show(strID);
            //MessageBox.Show(strCatName);
            //MessageBox.Show(strCatDesc);
            //MessageBox.Show(strCatPic);
            //int intData = Convert.ToInt32(strData);
            this.Close();
            Form SuppUpdForm = new SupplierUpdate(suppliersModel);
            SuppUpdForm.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            try
            {
                DataSet ds = new DataSet();
                SuppliersModel suppliersModel = new SuppliersModel();
                ds = suppliersModel.PopGrid(txtSearch.Text);
                if (ds.Tables.Count > 0)
                {
                    dataGridView1.DataSource = ds.Tables[0].DefaultView;
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Could not load data, please check Database Connection!");
            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
