﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NorthWindTask.Models;

namespace NorthWindTask
{
    public partial class SuppliersCreate : Form
    {
        public SuppliersCreate()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void SuppliersCreate_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SuppliersModel suppliersModel = new SuppliersModel();
            suppliersModel.SupplierID = 0;
            suppliersModel.CompanyName = txtCompanyName.Text;
            suppliersModel.ContactName = txtContactName.Text;
            suppliersModel.ContactTitle = txtContactTitle.Text;
            suppliersModel.Address = txtAddress.Text;
            suppliersModel.City = txtCity.Text;
            suppliersModel.Region = txtRegion.Text;
            suppliersModel.Country = txtCountry.Text;
            suppliersModel.Phone = txtPhone.Text;
            suppliersModel.Fax = txtFax.Text;
            suppliersModel.HomePage = txtHomePage.Text;

            suppliersModel.CreateSupplier(suppliersModel);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
